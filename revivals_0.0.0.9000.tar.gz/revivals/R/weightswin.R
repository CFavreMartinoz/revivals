

#' weightswin
#'
#' @param data  the original data set with the sample, the variable of interest
#' @param varname  the name of the variable of interest
#' @param gn  the population size
#' @param method  the sample design : si for simple random sampling , poisson, rejective
#' @param pii  first oder inclusion probabilities
#' @param typewin winsorized estimator : Beaumont et al., Standard or Dalen-Tambay
#' @param tailleseq  maximum iteration for the research of the minimum
#' @param remerge rue/False to remerge the conditional bias with the original data set
#'
#' @return Compute the robust weight associated to the winsorized estimator
#' @export

"weightswin.r"<-
  function (data, varname = NULL,gn,method="si", pii,typewin="BHR",tailleseq=10000,remerge=T)
  {
    if (missing(method)) {
      warning("the method is not specified; by default, the method is si")
      method = "si"
    }
    if (!(method %in% c("si", "poisson", "rejective")))
      stop("the name of the method is wrong")
    if (missing(typewin)) {
      warning("the type of winsorization is not specified; by default, the method is BHR")
      typewin = "BHR"
    }
    if (!(typewin %in% c("BHR", "standard", "DT")))
      stop("the name of the type of winsorization  is wrong")
    if (missing(pii))
      stop("the vector of probabilities is missing")
    data = data.frame(data)
    pn=nrow(data)
    index = 1:nrow(data)
    m = match(varname, colnames(data))
    if (any(is.na(m)))
      stop("the name of the variable is wrong")

    data2 = cbind.data.frame(data[, m], index)
    colnames(data2) = c(varname, "index")

    bc=HTcondbiasest(data, varname, gn, method, pii,remerge=F)

    if(length(m)!=ncol(bc))
      stop("the number of conditionnal bias is different from the number of variable of study")
    if (typewin == "BHR") {
      if (length(m)==1){
        tc=tuningconst(bc[,1],tailleseq=tailleseq)
        ditilde=(1/pii)-(bc[,1]-hub.psi(bc[,1],b=tc))/data[,m]
        ditilde[is.nan(ditilde)]=1/pii[is.nan(ditilde)]

      }else{
        tc=apply(bc,MARGIN = 2,tuningconst,tailleseq=tailleseq)

        ditilde=(1/pii)-(bc-mapply(x=bc,b=tc,hub.psi))/data[,m]
        ##Some weight might be Nan, since some data are equals to 0
        ##Since they don't contribute to the total, an arbitrary can be add, by default the orginal weight
        for(j in 1:length(bc)){
          ditilde[is.nan(ditilde[,j]),j]=1/pii[is.nan(ditilde[,j])]

        }


      }
    }
    if (typewin == "standard") {
      if (length(m)==1){


        ctws=determinconstws(di=1/pii,x=data[,m],bc,tailleseq)
        ditilde=(1/pii)*apply(cbind(data[,m],ctws*pii),MARGIN=1,min)/data[,m]
        ditilde[is.nan(ditilde)]=1/pii[is.nan(ditilde)]
      }else{
        tc=mapply(determinconstws,x=data[,m],bc=bc, MoreArgs = list(di = 1/pii,tailleseq=tailleseq))
        df=data[,m]
        df[data[,m]-t(c(tc)%*%t(c(pii)))>0]=t(c(tc)%*%t(c(pii)))[data[,m]-t(c(tc)%*%t(c(pii)))>0]
        ditilde=(1/pii)*df/data[,m]
        ##Some weight might be Nan, since some data are equals to 0
        ##Since they don't contribute to the total, an arbitrary can be add, by default the orginal weight
        for(j in 1:length(bc)){
          ditilde[is.nan(ditilde[,j]),j]=1/pii[is.nan(ditilde[,j])]

        }
      }
    }

    if (typewin == "DT") {
      if (length(m)==1){


        copt=determinconstwDT(di=1/pii,x=data[,m],bc,tailleseq)

        ditilde=1+(1/pii-1)*apply(cbind(data[,m],copt*pii),MARGIN=1,min)/data[,m]
        ditilde[is.nan(ditilde)]=1/pii[is.nan(ditilde)]
      }else{

        tc=mapply(determinconstwDT,x=data[,m],bc=bc, MoreArgs = list(di = 1/pii,tailleseq=tailleseq))
        df=data[,m]
        df[data[,m]-t(c(tc)%*%t(c(pii)))>0]=t(c(tc)%*%t(c(pii)))[data[,m]-t(c(tc)%*%t(c(pii)))>0]
        ditilde=1+(1/pii-1)*df/data[,m]
        ##Some weight might be Nan, since some data are equals to 0
        ##Since they don't contribute to the total, an arbitrary can be add, by default the orginal weight
        for(j in 1:length(bc)){
          ditilde[is.nan(ditilde[,j]),j]=1/pii[is.nan(ditilde[,j])]

        }

      }
    }
    if(remerge){
      result = cbind.data.frame(data,ditilde)
      colnames(result)=c(colnames(data),paste0("weights",typewin,colnames(ditilde)))
    }else{
      result =data.frame(ditilde)
      if(length(m)==1){
        colnames(result)=c(paste0("weights",typewin))
      }else{
        colnames(result)=c(paste0("weights",typewin,colnames(ditilde)))
      }
    }

    result
  }



#' determinconstwDT
#'
#' @param di  initial sampling weight : inverse of the first oder inclusion probabilities
#' @param x  variable of interest
#' @param bc  conditional bias
#' @param tailleseq  maximum iteration for the research of the minimum
#' @importFrom stats uniroot
#' @return Compute the robust weight associated to the Dalen-Tambay winsorized estimator
#' @export
#'

determinconstwDT=function(di,x,bc,tailleseq=1000){

  functiontDT=function(a,di,x,bc){
    testpos=function(x,tconst=1.345){
      res=rep(0,length(x))
      res[(x-tconst)>0]=(x-tconst)[(x-tconst)>0]
      return(res)
    }
    rest=-colSums(((di-1)/di)*sapply(a,testpos,x=as.matrix(di*x)))
    copt=rest+0.5*(min(bc)+max(bc))
    return(copt)
  }
  resultat<-uniroot(functiontDT, c(0, max(di*x)), check.conv = FALSE,tol = .Machine$double.eps^10, maxiter = tailleseq, trace = 0,di=di,x=x,bc=bc)

  return(resultat$root)



}


#' determinconstws
#'
#' @param di  initial sampling weight : inverse of the first oder inclusion probabilities
#' @param x  variable of interest
#' @param bc  conditional bias
#' @param tailleseq  maximum iteration for the research of the minimum
#' @importFrom stats uniroot
#' @return Compute the robust weight associated to the standard winsorized estimator
#' @export
#'

determinconstws=function(di,x,bc,tailleseq){

  functiontws=function(a,di,x,bc){
    testpos=function(x,tconst=1.345){
      res=rep(0,length(x))
      res[(x-tconst)>0]=(x-tconst)[(x-tconst)>0]
      return(res)
    }
    rest=-colSums(sapply(a,testpos,x=as.matrix(di*x)))
    copt=rest+0.5*(min(bc)+max(bc))
    return(copt)
  }
  resultat<-uniroot(functiontws, c(0, max(di*x)), check.conv = FALSE,tol = .Machine$double.eps^10, maxiter = tailleseq, trace = 0,di=di,x=x,bc=bc)

  return(resultat$root)
}




hub.psi <- function(x, b = 1.345)
{
  psi <- ifelse(abs(x) <= b, x, sign(x) * b)
  der.psi <- ifelse(abs(x) <= b, 1, 0)
  return(psi = psi)
}


#' tuningconst
#'

#' @param bi  conditional bias
#' @param tailleseq  maximum iteration for the research of the minimum
#' @importFrom stats optimize
#' @return Compute the robust weight associated to the Beaumont et al (2013) estimator
#' @export
#'

tuningconst=function(bi,tailleseq=1000){
  tuningconstBDR=function(c,bi,tailleseq=1000){
        res=sapply(c,hub.psi,x=bi)
        return(abs(colSums(res-bi)+0.5*(min(bi)+max(bi))))
  }
  resultat<-optimize(tuningconstBDR,interval=c(min(abs(bi)),max(abs(bi))),bi=bi,maximum = FALSE,tol = .Machine$double.eps^0.9)
  return(resultat$minimum)

}


