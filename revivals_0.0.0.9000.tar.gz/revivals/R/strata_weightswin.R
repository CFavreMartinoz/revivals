
#' strata_weightswin
#'
#' @param data : the original data set with the sample, the variable of interest
#' @param strataname : name of the variable use for stratification
#' @param varname : the name of the variable of interest
#' @param gnh : the population size in each stratum
#' @param method : the sample design : si for simple random sampling , poisson, rejective
#' @param pii : first oder inclusion probabilities
#' @param typewin : winsorized estimator : Beaumont et al., Standard or Dalen-Tambay
#' @param tailleseq : maximum iteration for the research of the minimum
#' @param remerge : True/False to remerge the conditional bias with the original data set
#'
#'
#' @return : the robust weight associated to the winsorized estimator
#' @export

"strata_weightswin.r" <-
  function (data, strataname = NULL,varname = NULL, gnh, method = c("si",
                                                                    "poisson", "rejective"), pii,typewin="BHR",tailleseq=10000,remerge=T)
  {
    if  (missing(gnh))
      stop("the population size vector is missing")
    if (missing(strataname) | is.null(strataname))
      stop("the strata name is missing")
    data = data.frame(data)
    index = 1:nrow(data)
    m = match(varname, colnames(data))
    if (any(is.na(m)))
      stop("the name of the variable is wrong")
    ms = match(strataname, colnames(data))
    if (any(is.na(ms)))
      stop("the name of the strata is wrong")
    if (missing(typewin)) {
      warning("the type of winsorization is not specified; by default, the method is BHR")
      typewin = "BHR"
    }
    if (!(typewin %in% c("BHR", "standard", "DT")))
      stop("the name of the type of winsorization  is wrong")
    x1 = data.frame(unique(data[,ms]))
    matw=matrix(0,nrow=nrow(data),ncol=length(m))
    cgn=0
    for (i in 1:nrow(x1)) {
      datastr=as.data.frame(data[(data[,ms]==i),m])
      colnames(datastr)=colnames(data)[m]
      nh=nrow(as.data.frame(datastr))
      piisrt=pii[(data[,ms]==i)]
      resint=weightswin.r(data=datastr, varname =varname , gn=gnh[i], method =method , pii=piisrt,typewin=typewin,tailleseq=tailleseq,remerge = F)
      matw[(cgn+1):(cgn+nh),]=as.matrix(resint)

      # bc[(cgn+1):(cgn+nh)]=nh[i]/(nh[i]-1)*(gnh[i]/nh-1)*(y-mean(y))
      cgn=cgn+nh

    }
    if(remerge){
      result = cbind.data.frame(data,matw)
      colnames(result)=c(colnames(data),colnames(resint))
      result
    }else{
      result = cbind.data.frame(matw)
      colnames(result)=c(colnames(resint))
      result
    }
  }
