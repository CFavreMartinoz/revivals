
#' robustest
#'
#' @param data  the original data set with the sample, the variable of interest
#' @param varname  the name of the variable of interest
#' @param gn  the population size
#' @param method  the sample design : si for simple random sampling , poisson, rejective
#' @param pii  first oder inclusion probabilities
#'
#' @return Compute the robust estimator of Beaumont and al.(2013) using the conditional bias and the minmax criterion to compute the tuning constant
#' @export
#'

"robustest" <-
  function (data, varname = NULL, gn, method = c("si",
                                                 "poisson", "rejective"), pii)
  {
    if (gn!=sum(1/pii)) {
      warning("the sum of the inclusion probabilities is not equal to N")

    }
    if (missing(method)) {
      warning("the method is not specified; by default, the method is si")
      method = "si"
    }
    if (!(method %in% c("si", "poisson", "rejective")))
      stop("the name of the method is wrong")
    if (method %in% c("poisson", "rejective") & missing(pii))
      stop("the vector of probabilities is missing")
    if  (missing(gn))
      stop("the population size is missing")
    data = data.frame(data)
    pn=nrow(data)
    index = 1:nrow(data)
    m = match(varname, colnames(data))
    if (any(is.na(m)))
      stop("the name of the variable is wrong")
    data2 = cbind.data.frame(data[, m], index)
    colnames(data2) = c(varname, "index")

    if (any(is.na(data[,m])))
      stop("Missing values for some y-variables")


    if (length(m)==1){

      htestim=crossprod(data[,m],1/pii)
      htbc=HTcondbiasest(data=data, varname = varname, gn=gn, method = method, pii=pii)[,c(seq(1+length(data),length(data)+length(varname)))]
      result=htestim-(min(htbc)+max(htbc))/2
    }else{
      htestim=(1/pii)%*%as.matrix(data[,m])
      htbc=HTcondbiasest(data=data, varname = varname, gn=gn, method = method, pii=pii)[,c(seq(1+length(data),length(data)+length(varname)))]
      result=htestim-(apply(X =htbc,MARGIN = 2,min )+apply(X =htbc,MARGIN = 2,max ))/2
    }

    colnames(result)=c(paste0("RHT",colnames(htbc)))


    result
  }





