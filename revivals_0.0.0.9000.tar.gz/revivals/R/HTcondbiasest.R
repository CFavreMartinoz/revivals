

#' HTcondbiasest
#' The function for estimating the conditional biases for the HT estimator of a total for the non-stratiﬁed sampling designs. For several given variables of interest as input, this function return a vector with the estimates of the conditional bias of the HT estimator where each row corresponds to a sample unit.
#' @param data  the original data set with the sample, the variable of interest
#' @param varname  the name of the variable of interest
#' @param gn  the population size
#' @param method  the sample design : si for simple random sampling , poisson, rejective
#' @param pii  first oder inclusion probabilities
#' @param remerge  True/False to remerge the conditional bias with the original data set
#'
#' @return Return a data set with the conditional biais of each sampled unit
#' @export
#'

"HTcondbiasest" <-function (data, varname = NULL, gn, method = c("si",
                                                 "poisson", "rejective"), pii,remerge=T)
  {
    if (gn!=sum(1/pii)) {
      warning("the sum of the inclusion probabilities is not equal to N")

    }
    if (missing(method)) {
      warning("the method is not specified; by default, the method is si")
      method = "si"
    }
    if (!(method %in% c("si", "poisson", "rejective")))
      stop("the name of the method is wrong")
    if (method %in% c("poisson", "rejective") & missing(pii))
      stop("the vector of probabilities is missing")
    if  (missing(gn))
      stop("the population size is missing")
    data = data.frame(data)
    pn=nrow(data)
    index = 1:nrow(data)
    m = match(varname, colnames(data))
    if (any(is.na(m)))
      stop("the name of the variable is wrong")
    data2 = cbind.data.frame(data[, m], index)
    colnames(data2) = c(varname, "index")
    if (method == "si") {
      if (length(m)==1){
        bc=(pn/(pn-1))*(gn/pn-1)*(data[,m]-mean(data[,m]))
      }else{
        bc=(pn/(pn-1))*(gn/pn-1)*(data[,m]-matrix(data=colMeans(data[,m]),nrow=pn,ncol=length(m), byrow =T))
      }
    }
    if (method == "poisson") {
      bc=(1/pii -1) * data[,m]
    }
    if (method == "rejective") {
      gd=sum(1-pii)
      gb=t(1/pii-1)%*%as.matrix(data[,m])/gd
      bc=(1/pii -1) * (data[,m]-t(t(gb)%*%c(pii)))
    }
    if(remerge){
      result = cbind.data.frame(data,bc)
      colnames(result)=c(colnames(data),paste0("condbias",colnames(bc)))
    }else{
      result =data.frame(bc)
      if(length(m)==1){
        colnames(result)=c("condbias")
      }else{
        colnames(result)=c(paste0("condbias",colnames(bc)))
      }
    }

    result
  }
