
#' strata_HTcondbiasest
#' The function for estimating the conditional biases for the HT estimator of a total for the stratiﬁed sampling designs. For several given variables of interest as input, this function return a vector with the estimates of the conditional bias of the HT estimator where each row corresponds to a sample unit.
#' @param data  the original data set with the sample, the variable of interest
#' @param strataname  name of the variable use for stratification
#' @param varname  the name of the variable of interest
#' @param gnh  the population size in each stratum
#' @param method  the sample design : si for simple random sampling , poisson, rejective
#' @param pii  first oder inclusion probabilities
#'
#' @return Return a dataframe with the conditional biais of each sampled unit
#' @export

"strata_HTcondbiasest" <-
  function (data, strataname = NULL,varname = NULL, gnh, method = c("si",
                                                                    "poisson", "rejective"), pii)
  {
    if  (missing(gnh))
      stop("the population size vector is missing")
    if (missing(strataname) | is.null(strataname))
      stop("the strata name is missing")
    data = data.frame(data)
    index = 1:nrow(data)
    m = match(varname, colnames(data))
    if (any(is.na(m)))
      stop("the name of the variable is wrong")
    ms = match(strataname, colnames(data))
    if (any(is.na(ms)))
      stop("the name of the strata is wrong")
    x1 = data.frame(unique(data[,ms]))
    bc=matrix(0,nrow=nrow(data),ncol=length(m))
    cgn=0

    for (i in 1:nrow(x1)) {

      datastr=as.data.frame(data[(data[,ms]==i),m])
      colnames(datastr)=colnames(data)[m]
      nh=nrow(as.data.frame(datastr))
      piisrt=pii[(data[,ms]==i)]
      sum(1/piisrt)==gnh[i]
      resint=HTcondbiasest(data=datastr, varname =varname , gn=gnh[i], method =method , pii=piisrt,remerge = F)
      bc[(cgn+1):(cgn+nh),]=as.matrix(resint)

      # bc[(cgn+1):(cgn+nh)]=nh[i]/(nh[i]-1)*(gnh[i]/nh-1)*(y-mean(y))
      cgn=cgn+nh
    }
    result = cbind.data.frame(data,bc)
    colnames(result)=c(colnames(data),colnames(resint))
    result
  }
